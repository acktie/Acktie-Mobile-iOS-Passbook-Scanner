// See github
// https://github.com/acktie/Acktie-Mobile-Passbook-Scanner